function printpage() {
	window.print();  
}

//*** Change to red dot on hover in menu
//NB! The images folder is "hardcoded"
if(document.images){
	pics = new Array();
	pics[1] = new Image();
	pics[1].src = "/images/black_dot.gif";
	pics[2] = new Image();
	pics[2].src = "/images/red_dot.gif";
}

function changer(id, img, direction) {
    if(document.images) {
    	//Change image 
    	document.images["bullet_" + id].src = pics[img].src;
    	elem = document.getElementById("link_" + id);
		// NB! We really wanted to set the className of the element, but IE refused to get the color right.
		// So these values must be kept in sync with the style sheet.
    	if (direction == "in"){
	    	elem.style.color = "red";
	    	elem.style.textDecoration = "underline";
	    }else{
	    	elem.style.color = "#333333";
	    	elem.style.textDecoration = "none";
	    }
    }
 }
function trim(s) {
  while (s.substring(0,1) == ' ') {
    s = s.substring(1,s.length);
  }
  while (s.substring(s.length-1,s.length) == ' ') {
    s = s.substring(0,s.length-1);
  }
  return s;
}

function setHeight(arr){
	if(document.getElementById){		
		var elements = new Array();
		//Get all elements to resize
		for(i=0;i<arr.length;i++){ elements[i] = document.getElementById(arr[i]);}
		//for(i=0;i<arr.length;i++){ elements[i].style.height = 'auto';}
		var h = 0;
		//Find max
		for(i=0;i<elements.length;i++){if (elements[i].offsetHeight > h) h = elements[i].offsetHeight;}
		//Set the height
		for(i=0;i<elements.length;i++){elements[i].style.height = h + 'px';}		
	}	
}

