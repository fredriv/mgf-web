/*
DHTML library for CoreTrek AS, www.coretrek.com
written by Arve Skj�restad
functions on this object:
ct_layer

Properties:
   .clickedX
   .clickedY

methods:
   .ct_layer(layName)
	.setTop(t)
	.getTop()
	.setLeft(l)
	.getLeft()
	.getRight()
	.getWidth()
   .setWidth(wi)
	.getHeight()
	.getBottom()
	.moveTo(l,t)
	.moveBy(l,t)
	.hide()
	.show()
	.setVisibility(v)
	.write(theText)
	.getZIndex()
	.setZIndex(z)
	
   (not impl)
   .clip
	.getClipLeft
	.getClipTop
	.getClipRight
	.getClipBottom
	.getClipWidth
	.getClipHeight
	.scrollTo
	.scrollBy
	.setBgColor
	.setBgImage

*/
//var objLayRef;
//var objLayName;
function ct_layer(layName)
	{
	//Make object reference
	if (document.getElementById)	
		{
		this.styleRef = document.getElementById(layName).style ;
		this.layRef = document.getElementById(layName);
		}
	else if (document.layers)
		{
		this.styleRef = document.layers[layName];
		this.layRef = this.styleRef;
		}
	else if (document.all)
		{
		this.styleRef = document.all[layName].style ;	
		this.layRef = document.all[layName];
		}
	// setting variables
	this.objLayName=layName;

	// assigning functions
	this.setTop = setTop;
	this.getTop = getTop;
	this.setLeft= setLeft;
	this.getLeft= getLeft;
	this.getRight=getRight;
	this.getWidth=getWidth;
	this.setWidth=setWidth;
	this.getHeight=getHeight;
	this.getBottom=getBottom;
	this.moveTo = moveTo;
	this.moveBy	= moveBy;
	this.hide = hide;
   this.show = show;
   this.setVisibility= setVisibility;
   this.isVisible= isVisible;
   this.write=write;
   this.setZIndex = setZIndex;
	this.getZIndex = getZIndex;

   this.scrollLayerBy=scrollLayerBy;
   this.getClipLeft=getClipLeft;
   this.getClipTop=getClipTop;
   this.getClipRight=getClipRight;
   this.getClipBottom=getClipBottom;
   this.clipLayer=clipLayer;

   this.setSource= setSource;

   
   this.clickedX = this.getLeft();
	this.clickedY = this.getTop();
	}

function getRef()	{		return this.styleRef;			}

function setTop(t)	{		this.styleRef.top = t ;					}

function getTop()	{		return parseInt(this.styleRef.top);		}

function setLeft(l)	{		this.styleRef.left = l ;				}

function getLeft()	{		return parseInt(this.styleRef.left);	}

function getRight()	{		return getLeft() + getWidth();		}

function getWidth() 
	{
	if (document.layers) 
		{
		if (this.styleRef.document.width)
			return(this.styleRef.document.width);
		else
			return(this.styleRef.clip.right - this.styleRef.clip.left);
		}
	else if (document.all) 
		{
		if (this.styleRef.pixelWidth)
			return(this.styleRef.pixelWidth);
		else
			return(document.all[this.objLayName].clientWidth);
		}	
	else if (document.getElementById)
		{
      return parseInt(this.layRef.offsetWidth);
      }
	else
		return false;
	}

function setWidth(wi)
	{
	if (document.layers) 
		{
		this.styleRef.resizeTo(wi,this.getHeight());
		}
	else if (document.all) 
		{
      this.layRef.offsetWidth= wi;
      //this.styleRef.width = wi;
      }	
	else if (document.getElementById)
		{
		this.styleRef.width = wi;
		}
	else
		return false; 
   }

function getHeight() 
	{
	if (document.layers) 
		{
		if (this.styleRef.document.height)
			return(this.styleRef.document.height);
		else
			return(this.styleRef.clip.bottom - this.styleRef.clip.top);
		}
	else if (document.all) 
		{
		if (false && this.styleRef.pixelHeight)
			return(this.styleRef.pixelHeight);
		else
			return(document.all[this.objLayName].clientHeight);
		}
	else if (document.getElementById)
		{
		return(parseInt(this.layRef.offsetHeight));
		}
	else
	return false;
	}

function getBottom()	{	return getTop()+getHeight() ;	}

function moveTo(l,t)
	{
	if(document.layers)
		this.styleRef.moveTo(l,t);
	else
		{
		this.styleRef.left = l;
		this.styleRef.top = t;
		}
	}

function moveBy(l,t)
	{
	if(document.layers)
		this.styleRef.moveBy(l,t);
	else
		{
		this.styleRef.left += l;
		this.styleRef.top += t;
		}
	}

function setVisibility(v)
	{	
	//Different words...Fix it!!	
	//If Netscape words are given, set NSv to this, and change v to DOM words
	//else set NSv to Netscape words	
   if(v=="hidden" || v=="hide") 
		{
		NSv="hide";
		v ="hidden";
		}
	else 
		{
		NSv="show";
		v ="visible";
		}

	if (document.getElementById)	
		this.styleRef.visibility = v;
	
	else if (document.layers)
		this.styleRef.visibility = NSv ;

	else if (document.all)
		this.styleRef.visibility = v ;	
	else
		return false;
	}

function isVisible() {
	if (document.getElementById)	
		if(this.styleRef.visibility == "hidden")
			return false;
		else 
			return true;
	
	else if (document.layers)
		if(this.styleRef.visibility == "hide")
			return false;
		else 
			return true;

	else if (document.all)
		if(this.styleRef.visibility == "hidden")
			return false;
		else 
			return true;

}

function hide()	{	this.setVisibility("hidden");	}

function show()	{	this.setVisibility("visible");	}

function write(theText)
	{
	if (document.layers)
		{
		this.styleRef.document.write(theText);
		this.styleRef.document.close();
		}
	else if (document.all)
		document.all[this.objLayName].innerHTML =theText;
	else if(document.getElementById)
		document.getElementById(this.objLayName).innerHTML =theText;
	else
		return false;
	}

function getZIndex() {	return this.styleRef.zIndex;	}

function setZIndex(z) {	this.styleRef.zIndex=z;			}

function clipLayer(clipleft, cliptop, clipright, clipbottom) {

  if (document.layers) {
    this.layRef.clip.left   = clipleft;
    this.layRef.clip.top    = cliptop;
    this.layRef.clip.right  = clipright;
    this.layRef.clip.bottom = clipbottom;
  }
  if (document.all)
    this.layRef.style.clip = 'rect(' + cliptop + ' ' +  clipright + ' ' + clipbottom + ' ' + clipleft +')';
}


function scrollLayerTo(x, y, bound) 
   {
   var dx = getClipLeft() - x;
   var dy = getClipTop() - y;
   
   scrollLayerBy( -dx, -dy, bound);
   }

function scrollLayerBy(dx, dy, bound) 
   {
   var cl = this.getClipLeft();
   var ct = this.getClipTop();
   var cr = this.getClipRight();
   var cb = this.getClipBottom();
   
   if (bound) 
      {
      if (cl + dx < 0)
         dx = -cl;
   
      else if (cr + dx > getWidth())
         dx = getWidth() - cr;
      if (ct + dy < 0)
         dy = -ct;
      else if (cb + dy > getHeight())
         dy = getHeight() - cb;
      }

  this.clipLayer( cl + dx, ct + dy, cr + dx, cb + dy);
  this.moveBy(-dx, -dy);
   }

function getClipLeft() 
   {
   if (document.layers)
      return this.layRef.clip.left;
   if (document.all) 
      {
      var str =  this.layRef.style.clip;
      if (!str)
         return(0);
      var clip = getIEClipValues(this.layRef.style.clip);
      return(clip[3]);
      }
   return(-1);
   }

function getClipTop() 
   {

   if (document.layers)
      return(this.layRef.clip.top);
   if (document.all) 
      {
      var str =  this.layRef.style.clip;
      if (!str)
         return(0);
      var clip = getIEClipValues(this.layRef.style.clip);
      return(clip[0]);
      }      
   return(-1);
   }

function getClipRight() 
   {
   if (document.layers)
      return(this.layRef.clip.right);
   if (document.all) 
      {
      var str =  this.layRef.style.clip;
      if (!str)
         return(this.layRef.style.pixelWidth);
      var clip = getIEClipValues(this.layRef.style.clip);
      return(clip[1]);
      }
   return(-1);
   }

function getClipBottom() 
   {
   if (document.layers)
      return(this.layRef.clip.bottom);
   if (document.all) 
      {
      var str =  this.layRef.style.clip;
      if (!str)
         return(this.layRef.style.pixelHeight);
      var clip = getIEClipValues(this.layRef.style.clip);
      return(clip[2]);
      }
   return(-1);
   }

function getClipWidth() 
   {
   if (document.layers)
      return(this.layRef.clip.width);
   if (document.all) 
      {
      var str = this.layRef.style.clip;
      if (!str)
         return(this.layRef.style.pixelWidth);
      var clip = getIEClipValues(this.layRef.style.clip);
      return(clip[1] - clip[3]);
      }
   return(-1);
   }

function getClipHeight() 
   {
   if (document.layers)
      return(this.layRef.clip.height);
   if (isMinIE4) 
      {
      var str =  this.layRef.style.clip;
      if (!str)
         return(this.layRef.style.pixelHeight);
      var clip = getIEClipValues(this.layRef.style.clip);
      return(clip[2] - clip[0]);
      }
   return(-1);
   }

function getIEClipValues(str) 
   {
   var clip = new Array();
   var i;

   // Parse out the clipping values for IE layers.
   
   i = str.indexOf("(");
   clip[0] = parseInt(str.substring(i + 1, str.length), 10);
   i = str.indexOf(" ", i + 1);
   clip[1] = parseInt(str.substring(i + 1, str.length), 10);
   i = str.indexOf(" ", i + 1);
   clip[2] = parseInt(str.substring(i + 1, str.length), 10);
   i = str.indexOf(" ", i + 1);
   clip[3] = parseInt(str.substring(i + 1, str.length), 10);
   return(clip);
   }

function setSource(win_url,width,height,scrolling)
   {
   sc = "no";
   if (document.layers) 
		{
      this.layRef.src  = win_url;
      } 
	else // If IE or NS 6, write an iframe.
		{
      extra ="";
      if(width && height)
         extra = " width=\""+width+"\" height=\""+height+"\" ";
      else
         extra ="";

      if(scrolling == true)
         sc="yes";

       // Write inner HTML for layer
       theHTML = "<iframe "+extra+" frameborder=0 framespacing=0 marginheight=0 src=\""+win_url+"\" codebase=\"browser\" scrolling="+scrolling+" type=\"text/html\"></iframe>";
      this.layRef.innerHTML= theHTML;
      }
   }

/*
	
	(not impl)
   .clip
	.getClipLeft
	.getClipTop
	.getClipRight
	.getClipBottom
	.getClipWidth
	.getClipHeight
	.scrollTo
	.scrollBy
	.setBgColor
	.setBgImage



	*/