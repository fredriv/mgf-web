/**
*	javascript.js
*	
*   This is the default javascript functions of CoreTreks Site Base for CorePublish frontends
*	
*	Please DO NOT CHANGE this file. 
*	To add your own functions, put them in another file
*	This makes sure you can update this file (javascript.js)
*	from a newer distribution without worrying about keeping your changes.
*
*	@author Arve Skj�restad
*	
*/

var timervar = null; 

function printArticle( artUrl ){
    behind = window.open(artUrl ,'printwin','height=650,width=810,status=yes,toolbar=yes,directories=no,menubar=no,location=no,resizable=no,scrollbars=yes');
}

function getContentAreaHeight() {
    if (document.all) {
        var ret  =  document.all["menuheighholder"].height;
    } else if (document.getElementById) {
		var ret =  document.getElementById("menuheighholder").height;
    }

    return  ret;

}       

function getAbsolutePos(el){
	for (var lx=0,ly=0;el!=null;
		lx+=el.offsetLeft,ly+=el.offsetTop,el=el.offsetParent);
	return {x:lx,y:ly}
}


/**
 * Sets the active stylesheet for the page.
 * 
 * 
 */
function setActiveStyleSheet(title) {
   var i, a, main;
   for(i=0; (a = document.getElementsByTagName("link")[i]); i++) {
       if(a.getAttribute("rel").indexOf("style") != -1
          && a.getAttribute("title")) {
           a.disabled = true;
           if(a.getAttribute("title") == title) {
               a.disabled = false;
           }
       }
   }
}

function getActiveStyleSheet() {
    var i, a;
    for(i=0; (a = document.getElementsByTagName("link")[i]); i++) {
        if(a.getAttribute("rel").indexOf("style") != -1
           && a.getAttribute("title")
           && !a.disabled) { 
            return a.getAttribute("title");
        }
    }
    return null;
}

var debugwin;
var debugwinopened = false;
function debug(str) {
    //return;
    // alert(str); return ;
	if (debugwinopened == false || !debugwin) {
        debugwin = window.open('about:blank','debug_window','width=1000,height=700, toolbars=no,menu=no,scrollbars=yes');
        debugwin.document.write("<h3>CorePublish Javascript Debug</h3>");
        debugwinopened = true;
    }
	debugwin.document.write( str );
	debugwin.focus();
    // make the debug win go away after a while..
    setTimeout("self.focus()",2000);
	// alert(str);
}

/**
*   Function displays the metods and properties of an javascript object
*   @param Object inarray - The array to serialize.
*/
function jsdebug(inarray, level) {
    var result = '';
    var sep = '';

    if (level > 5) {
        return;
    }

    if(inarray!=null) {
        for(var key in inarray) {
            
            if (inarray[key] == null) {
                continue;
            }

            result = "<ul>" +  typeof inarray[key];
            result += ' [' + key + '] => ';

            try {
                tmp = inarray[key].toString();
                result += tmp.substring(0,90) + "";
            } catch (e) {
                result += tmp + "";
            } 

            debug(result);
                
            if (typeof inarray[key] == "object" || typeof inarray[key] == "function") {
                jsdebug(inarray[key],level+1);
            }

            debug("</ul>");
            /*
            if(typeof inarray[key] == 'object') {
                result += '[object]';
            } else {
                result += inarray[key].toString();
            }     */



            /*if (result.length > 1000) {
                alert(result + " (continues >>) ");
                result = "";
            } */

        } 
    } else {
        result = "[null]";
    }
    // alert(result);
}
