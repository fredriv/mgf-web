function getWindowWidth(){
var winW=0;
if (parseInt(navigator.appVersion)>3) {
 if (navigator.appName=="Netscape") {
  winW = window.innerWidth;
 }
 if (navigator.appName.indexOf("Microsoft")!=-1) {
  winW = document.body.offsetWidth;
 }
}
return winW;
}

function getPercentOffset(percent){
var width = getWindowWidth();
var result=width*percent/100;  
return result; 
}
