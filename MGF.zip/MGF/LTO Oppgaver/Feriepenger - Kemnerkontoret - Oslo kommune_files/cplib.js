
/*
Common JavaScript functions for 
CPLIB - CorePublish 

Written by 
Arve Skj�restad 
CoreTrek AS

Modified:
	12.07.2001	Arve Skj�restad
		- changed slideshow() so that it can display more than 10 images.
*/

// variable declarations
var cp2_loaded = false;
var cp2_keywordlayer;
var x;
var y;


/***************** Common functions. ********************************/

/*
  	function to init 
*/
function cp2_init()
	{
	// Mouse position capture
	ns4 = document.layers?true:false;
	ns5 = (document.getElementById && !document.all)?true:false;
	ie5 = document.all?true:false;
	ie4 = (!document.getElementById && document.all)?true:false;
	
	if(ns4 || ns5)
	 document.captureEvents(Event.MOUSEMOVE);
	
	document.onmousemove=catchXY;

	// setting up keyword layer
	cp2_keywordlayer = new ct_layer("cp2keywordlayer");

	// Tell that document is loaded.
	cp2_loaded = true;
	}

// Calling the init function.
window.onload = cp2_init;
document.onclick = cp2_keywords_hide;

/*
	This is a function to catch the x and y coordinates of the mouse
*/
function catchXY(e)
   {
   // capture click coordinates
   x=(ns4 || ns5)?e.pageX:event.x+document.body.scrollLeft;
   y=(ns4 || ns5)?e.pageY:event.y+document.body.scrollTop;
   //window.status= "x:"+x+" y:"+y;
   }


/*
  function to easy open an window
*/
function ct_win(win_url,height,width, props) {
	win_name = "ct_win";
    if (props &&  props.length > 1 ) {
        win_props = props ;
    } else {
        win_props ="height="+height+",width="+width+",screenX=400,screenY=100";
    }
	window.open(win_url,win_name,win_props);
}

/***************** Image and preload functions. ********************************/

function ct_image(img)
	{
	if(!cp2_loaded) {
		return false;
    }

	a=new Image(); 
	a.src=img; 
	return a;
	} 

function ct_swap(docname,swapimage)
	{
	if(!cp2_loaded)
		return;
	document[docname].src = swapimage.src ;
	}

/***************** Functions used by article elements ********************************/


/*
  	slideshow function, used to navigate back and forward 
	in a slideshow element.
*/
function slideshow(thearray,imgname,pos,what,theform){
	if(!cp2_loaded)
		return;

	i=eval("slidepos"+pos);
	count=eval("count"+pos);
	
	// Show next picture
	if(what=="next" && thearray[i+1])
		{
		// Load image before we display it, then swap
		temp = ct_image(thearray[i+1]);
		document[imgname].src = temp.src;
		eval("slidepos"+pos+"++"); // increase counter
		theform.slidetext.value = (i+2)+ " av "+ count; // Set status text
		}
	
	// Show previous picture
	if(what=="previous" && i>0 && thearray[i-1])
		{
		temp = ct_image(thearray[i-1]);
		document[imgname].src = temp.src;
		eval("slidepos"+pos+"--");
		theform.slidetext.value = (i)+ " av "+ count;
		}
	}

/*
	Function to display keywords in a litle popup box.
*/
function cp2_keywords(keyword_id) {
	cp2_keywordlayer.moveTo(x,y);
	cp2_keywordlayer.setSource("keywords_popup.php?id="+keyword_id,160,160);
	cp2_keywordlayer.show();
}

function cp2_keywords_hide() {
	if(!cp2_loaded)
	   return;

	if(cp2_keywordlayer.isVisible())
		cp2_keywordlayer.hide();
}


/**
*   function that returns the position for the given element.
*
*
*
*/
function getAbsoluteElementPosition(el){
	for (var lx=0,ly=0;el!=null;
		lx+=el.offsetLeft,ly+=el.offsetTop,el=el.offsetParent);
	return {x:lx,y:ly}
}
