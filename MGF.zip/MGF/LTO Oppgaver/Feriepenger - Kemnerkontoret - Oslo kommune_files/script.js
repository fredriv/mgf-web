// $Id: script.js,v 1.2 2006/10/02 11:51:20 md Exp $
// Alter these text vars to localize the webreader
var PlayButtonAltText="Les opp markert tekst [Alt+L]";
var HelpButtonAltText="Hjelp [Alt+J]";
var StopButtonAltText="Stopp avspilling [Alt+S]";
var ConfigButtonAltText="Lesehastighet [Alt+I]";
var notextError="Det er ikke markert noen tekst!";
var noPopUpError="Det har oppst&aring;tt en feil, som muligvis skyldes blokeringen av pop-up vindu! For &aring; h&oslash;re opplesingen m�=&aring; du tillate pop-up vinduer.";

var SpeedHeader="Hastighet";
var SpeedLevel1="H&oslash;y";
var SpeedLevel2="Normal";
var SpeedLevel3="Lav";

var SCModeHeader = "Konverterings modus"
var TitleSCMode1 = 'HQ streaming';
var TitleSCMode2 = 'LQ streaming';
var TitleSCMode3 = 'LQ enkel fil';
var CloseDialog="Lukk";


// Alter this to reflect you API server
var pafapiserver="http://"+window.location.hostname+"/leseweb/";
var pafconverterserver="http://speech.voiceasp.no/apidata/";

//sizes of configuration window
var ConfigWindowHeight = 65;
var ConfigWindowWidth = 140;
var PopupWindowName = 'PAF_popup_WIN';
var const_pafplayerscmode = 'pafplayerscmode';
var const_pafplayerspeed = 'pafplayerspeed';

//alter this options to enable/disable features of the script
var OptionSearchInFrames = 1;
var OptionUsePopupWindow = 1;

var topoffset;
var leftoffset;
var paftoolbarwin;
var pafplaystatus;
var themp3file;
var PAFhelpurl;
var PAFpitch;
var PAFspeed;
var PAFlicense;
var PAFPlayer=null;
var textToRead="";
var iframe, iframeDocument;
var iframeID = "MyHiddenIFrame";
var extendedplayer=false;
var sp1;
var sp2;
var sp3;

//speech conversion modes - constants
var SCMODE1= 0;
var SCMODE2= 1;
var SCMODE3= 2;

var PlayerSpeed;
var eventFunction='';
var PopupWindowInstance;

/////////////////////////////////////////////////////////////////////////////////////////////
// Functions to determine positions of an element on the screen (they are required to position popup window)
// Functions are modified comparing with original ones - a support of frames & opera were improved.
// Author: Matt Kruse <matt@mattkruse.com> 
// WWW: http://www.mattkruse.com/
// getAnchorPosition(anchorname)
//   This function returns an object having .x and .y properties which are the coordinates
//   of the named anchor, relative to the page.
function getAnchorPosition(anchorname) {
	// This function will return an Object with x and y properties
	var useWindow=false;
	var coordinates=new Object();
	var x=0,y=0;
	// Browser capability sniffing
	var use_gebi=false, use_css=false, use_layers=false;
	if (document.getElementById) { use_gebi=true; }
	else if (document.all) { use_css=true; }
	else if (document.layers) { use_layers=true; }
	// Logic to find position
 	if (use_gebi && document.all) {
		x=AnchorPosition_getPageOffsetLeft(document.all[anchorname]);
		y=AnchorPosition_getPageOffsetTop(document.all[anchorname]);
	} else if (use_gebi) {
		var o=document.getElementById(anchorname);
		x=AnchorPosition_getPageOffsetLeft(o);
		y=AnchorPosition_getPageOffsetTop(o);
	} else if (use_css) {
		x=AnchorPosition_getPageOffsetLeft(document.all[anchorname]);
		y=AnchorPosition_getPageOffsetTop(document.all[anchorname]);
	} else if (use_layers) {
		var found=0;
		for (var i=0; i<document.anchors.length; i++) {
			if (document.anchors[i].name==anchorname) { found=1; break; }
		}
		if (found==0) {
			coordinates.x=0; coordinates.y=0; return coordinates;
		}
		x=document.anchors[i].x;
		y=document.anchors[i].y;
	} else {
		coordinates.x=0; coordinates.y=0; return coordinates;
	}
	coordinates.x=x;
	coordinates.y=y;
	return coordinates;
}

// getAnchorWindowPosition(anchorname)
//   This function returns an object having .x and .y properties which are the coordinates
//   of the named anchor, relative to the window
function getAnchorWindowPosition(anchorname) {
	var coordinates=getAnchorPosition(anchorname);
	var x=0, y=0;
	if ( (!isopera()) && document.getElementById) { //modified by dv
		if (isNaN(window.screenX)) {
			x=coordinates.x-document.body.scrollLeft+window.screenLeft;
			y=coordinates.y-document.body.scrollTop+window.screenTop;
		} else { 
			if (window.frameElement) { 
				x=coordinates.x+window.screenX+window.frameElement.offsetLeft;
				y=coordinates.y+window.screenY+window.frameElement.offsetTop;
			} else {
				x=coordinates.x+window.screenX+(window.outerWidth-window.innerWidth)-window.pageXOffset;
				y=coordinates.y+window.screenY+(window.outerHeight-24-window.innerHeight)-window.pageYOffset;
			}
		}
	} else if (document.all) {
		x=coordinates.x-document.body.scrollLeft+window.screenLeft;
		y=coordinates.y-document.body.scrollTop+window.screenTop;
	} else if (document.layers) {
		x=coordinates.x+window.screenX+(window.outerWidth-window.innerWidth)-window.pageXOffset;
		y=coordinates.y+window.screenY+(window.outerHeight-24-window.innerHeight)-window.pageYOffset;
	}
	coordinates.x=x;
	coordinates.y=y;
	return coordinates;
}

// Functions for IE to get position of an object
function AnchorPosition_getPageOffsetLeft (el) {
	var ol=el.offsetLeft;
	while ((el=el.offsetParent) != null) { ol += el.offsetLeft; }
	return ol;
}
function AnchorPosition_getWindowOffsetLeft (el) {
	return AnchorPosition_getPageOffsetLeft(el)-document.body.scrollLeft;
}	
function AnchorPosition_getPageOffsetTop (el) {
	var ot=el.offsetTop;
	while((el=el.offsetParent) != null) { ot += el.offsetTop; }
	return ot;
}
function AnchorPosition_getWindowOffsetTop (el) {
	return AnchorPosition_getPageOffsetTop(el)-document.body.scrollTop;
}
// public method for url encoding
function encode_to_utf8(SrcStr) {
//http://ecmanaut.blogspot.com/2006/07/encoding-decoding-utf8-in-javascript.html
	return unescape(encodeURIComponent(SrcStr));
}
/////////////////////////////////////////////////////////////////////////////////////////////


function writecookie(Speed, ScMode){
	var sdate = "expires=Fri, 27 Jul 2050 02:47:11 UTC;";
  if (Speed==sp1) {document.cookie="speed=sp1;"+sdate};
  if (Speed==sp2) {document.cookie="speed=sp2;"+sdate};
  if (Speed==sp3) {document.cookie="speed=sp3;"+sdate};
  if (ScMode==SCMODE1){document.cookie="scmode=SCMODE1;"+sdate};
  if (ScMode==SCMODE2){document.cookie="scmode=SCMODE2;"+sdate};
  if (ScMode==SCMODE3){document.cookie="scmode=SCMODE3;"+sdate};
}

function formcode(atext)
{
	var thespeed=PAFspeed;
	var thescmode=SCMODE1;
  if (extendedplayer) {
    thespeed = document.getElementById(const_pafplayerspeed).value;
		thescmode = document.getElementById(const_pafplayerscmode).value;
    writecookie(thespeed, thescmode);
  }
//  var test=document.cookie;

  var code ="<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0 Transitional//EN\">";
  code=code+"<html><head><META HTTP-EQUIV=\"Content-Type\" content=\"text/html; charset=UTF-8\"></head><body>";
  code=code+"<form id=startplay name=test action=\""+pafconverterserver+"player.paf\" method=post>";
  code=code+"<input type=hidden name=text ID=\"text\" value=\""+atext+"\"><input type=hidden name=pitch VALUE=\""+PAFpitch+"\" ID=\"pitch\">";
  code=code+"<input type=hidden name=speed ID=\"speed\" value=\""+thespeed+"\">";
  code=code+"<input type=hidden name=license VALUE=\""+PAFlicense+"\" ID=\"license\">";
  code=code+"<input type=hidden name=scmode ID=\"scmode\" value=\""+thescmode+"\">";
	code=code+"<input type=hidden value=\""+document.location.href+"\" name=site></form></body></html>"; 
  return code;
}

function iframecodes()
{
  var code="<iframe name=\"pafiframe\" id=\"pafiframe\" style=\"WIDTH:100px;HEIGHT:100px;BORDER:5px\"></iframe>";
  return code;
}

function pafsplayerspeedregulator()
{
  var sel1="", sel3="";
	var scmode_sel2 ="", scmode_sel3 ="";

	var list_cookies = document.cookie.split("; "); //space is required, it's added by the system
	for (var i=0; i < list_cookies.length; i++) {
		var cook = list_cookies[i];
	  if (cook=="speed=sp1"){sel1="selected"}
	  else if (cook=="speed=sp3"){sel3="selected"}
  	else if (cook=="scmode=SCMODE2"){scmode_sel2="selected"}
  	else if (cook=="scmode=SCMODE3"){scmode_sel3="selected"};
  };

//default values
	var sel2 = (sel1 =="" && sel3 == "") ? "selected" : "";
	var scmode_sel1 = (scmode_sel2=="" && scmode_sel3=="") ? "selected" : "";


  var code = "<div id=\"configpage\" style=\"POSITION:absolute;VISIBILITY:hidden;WIDTH:"+ConfigWindowWidth+"px;HEIGHT:"+ConfigWindowHeight+"px;"
  code = code + "background-image:url('"+pafapiserver+"bg3.gif')\">";
  code = code + "<table style=\"WIDTH:100%;BORDER:0px\" border=0 cellspacing=0 cellpadding=0>";

  code = code + "<tr><td style=\"font-family:verdana,ariel;font-size:10px;font-weight:bold;\">"+SpeedHeader+"</td>";
  code = code + "<td><select style=\"font-family:Verdana,Ariel;font-size:10px;margin-bottom:1px\" id=\""+const_pafplayerspeed+"\" onchange=\"javascript:change_speed()\">";
  code = code + "<option "+sel1+" value=\""+sp1+"\">"+SpeedLevel1+"</option>";
  code = code + "<option "+sel2+" value=\""+sp2+"\">"+SpeedLevel2+"</option>";
  code = code + "<option "+sel3+" value=\""+sp3+"\">"+SpeedLevel3+"</option>";
  code = code + "</select></td></tr>";

  code = code + "<tr><td style=\"font-family:verdana,ariel;font-size:10px;font-weight:bold;\">"+SCModeHeader+"</td>";
  code = code + "<td><select style=\"font-family:Verdana,Ariel;font-size:10px;margin-bottom:1px\" id=\""+const_pafplayerscmode+"\" onchange=\"javascript:change_scmode()\">";
  code = code + "<option "+scmode_sel1+" value=\""+SCMODE1+"\">"+TitleSCMode1+"</option>";
  code = code + "<option "+scmode_sel2+" value=\""+SCMODE2+"\">"+TitleSCMode2+"</option>";
  code = code + "<option "+scmode_sel3+" value=\""+SCMODE3+"\">"+TitleSCMode3+"</option>";
  code = code + "</select></td></tr>";

  code = code + "<tr><td align=center colspan=2><input type=button value="+CloseDialog+" onclick=\"javascript:close_configuration_window()\"></td></tr></table></div>";
  return code;
}

function configbutton()
{
  var code="<input type=\"image\" alt=\""+ConfigButtonAltText+"\" src='"+pafapiserver+"setting.gif' ";
  code=code+"onclick=\"javascript:showconfigs()\" ACCESSKEY=\"I\" ";
  code=code+"onmouseover=\"this.src='"+pafapiserver+"setting_up.gif'\" ";
  code=code+"onmouseout=\"this.src='"+pafapiserver+"setting.gif'\">";
  return code;
}

function notietoolbarcode()
{
  var code= "<div id=\"PAFTOOLBAR\" style=\"position:absolute;left:"+leftoffset+"px;top:"+topoffset+"px;z-index:10000;visibility:visible\">";
  code=code+"<table border=0 cellspacing=0 cellpadding=0><tr><td>";
  code=code+"<input type=\"image\" alt=\""+PlayButtonAltText+"\" src='"+pafapiserver+"playknap.gif' ";
  code=code+"onmousedown=\"doplay()\"  ACCESSKEY=\"L\" ";
  code=code+"onmouseover=\"this.src='"+pafapiserver+"playknap_up.gif'\" ";
  code=code+"onmouseout=\"this.src='"+pafapiserver+"playknap.gif'\">";
  code=code+"<input type=\"image\" alt=\""+StopButtonAltText+"\" src='"+pafapiserver+"stop.gif' ";
  code=code+"onclick=\"javascript:document.location.href=document.location.href;\" ACCESSKEY=\"S\" ";
  code=code+"onmouseover=\"this.src='"+pafapiserver+"stop_up.gif'\" ";
  code=code+"onmouseout=\"this.src='"+pafapiserver+"stop.gif'\">";
  code=code+"<input type=\"image\" alt=\""+HelpButtonAltText+"\" src='"+pafapiserver+"help.gif' ";
  code=code+"onclick=\"javascript:dohelp();\" ACCESSKEY=\"J\" ";
  code=code+"onmouseover=\"this.src='"+pafapiserver+"help_up.gif'\" ";
  code=code+"onmouseout=\"this.src='"+pafapiserver+"help.gif'\">";
  if (extendedplayer){code=code+configbutton()+pafsplayerspeedregulator()}
  //if (extendedplayer){code=code+pafsplayerspeedregulator()}
  code=code+"<a id=\"PAFimg\"><img src='"+pafapiserver+"api_logo.gif' border=0></a></td></tr></table></div>";
  return code;
}

function operatoolbarcode()
{
  var code= "<div id=\"PAFTOOLBAR\" style=\"position:absolute;left:"+leftoffset+"px;top:"+topoffset+"px;z-index:10000;visibility:visible\">";
  code=code+"<table border=0 cellspacing=0 cellpadding=0><tr><td valign=middle>";
  code=code+"<input type=\"button\" value=\"Play\" style=\"WIDTH:35px;HEIGHT:30px;MARGIN-BOTTOM:4px\" title=\""+PlayButtonAltText+"\" ";
  code=code+"onmousedown=\"doplay()\">";
  code=code+"<input style=\"MARGIN-BOTTOM:0px\" type=\"image\" alt=\""+StopButtonAltText+"\" src='"+pafapiserver+"stop.gif' ";
  code=code+"onclick=\"javascript:document.location.href=document.location.href;\" ACCESSKEY=\"S\" ";
  code=code+"onmouseover=\"this.src='"+pafapiserver+"stop_up.gif'\" ";
  code=code+"onmouseout=\"this.src='"+pafapiserver+"stop.gif'\">";
  code=code+"<input style=\"MARGIN-BOTTOM:0px\" type=\"image\" alt=\""+HelpButtonAltText+"\" src='"+pafapiserver+"help.gif' ";
  code=code+"onclick=\"javascript:dohelp();\" ACCESSKEY=\"J\" ";
  code=code+"onmouseover=\"this.src='"+pafapiserver+"help_up.gif'\" ";
  code=code+"onmouseout=\"this.src='"+pafapiserver+"help.gif'\">";
  if (extendedplayer){code=code+configbutton()+pafsplayerspeedregulator()}
  code=code+"<a id=\"PAFimg\"><img src='"+pafapiserver+"api_logo.gif' border=0></a></td></tr></table></div>";
  return code;
}

function ietoolbarcode()
{
  var code= "<div id=\"PAFTOOLBAR\" style=\"position:absolute;left:"+leftoffset+"px;top:"+topoffset+"px;z-index:10000;visibility:visible\">";
  code=code+"<table border=0 cellspacing=0 cellpadding=0><tr><td>";
  code=code+"<input type=\"image\" alt=\""+PlayButtonAltText+"\" src='"+pafapiserver+"playknap.gif' ";
  code=code+"onclick=\"javascript:doplay();\"  ACCESSKEY=\"L\" ";
  code=code+"onmouseover=\"this.src='"+pafapiserver+"playknap_up.gif'\" ";
  code=code+"onmouseout=\"this.src='"+pafapiserver+"playknap.gif'\">";

  code=code+"<input type=\"image\" alt=\""+StopButtonAltText+"\" src='"+pafapiserver+"stop.gif' ";
  code=code+"onclick=\"javascript:document.location.href=document.location.href;\" ACCESSKEY=\"S\" ";
  code=code+"onmouseover=\"this.src='"+pafapiserver+"stop_up.gif'\" ";
  code=code+"onmouseout=\"this.src='"+pafapiserver+"stop.gif'\">";

  code=code+"<input type=\"image\" alt=\""+HelpButtonAltText+"\" src='"+pafapiserver+"help.gif' ";
  code=code+"onclick=\"javascript:dohelp();\" ACCESSKEY=\"J\" ";
  code=code+"onmouseover=\"this.src='"+pafapiserver+"help_up.gif'\" ";
  code=code+"onmouseout=\"this.src='"+pafapiserver+"help.gif'\">";
  if (extendedplayer){code=code+configbutton()+pafsplayerspeedregulator()}
  code=code+"<a id=\"PAFimg\"><img src='"+pafapiserver+"api_logo.gif' border=0></a></td></tr></table></div>";
  return code;
}


function close_configuration_window()
{
		document.getElementById('configpage').style.visibility='hidden';
		if (OptionUsePopupWindow) {
			if (PopupWindowInstance) PopupWindowInstance.close();	
		}
}

function change_speed() 
{
//sync value of the speed: main window -> popup window
		if (PopupWindowInstance) {
			PopupWindowInstance.document.getElementById(const_pafplayerspeed).value = document.getElementById(const_pafplayerspeed).value;
		}
}

function change_scmode() 
{
//sync value of speech conversion mode: main window -> popup window 
		if (PopupWindowInstance) { 
//!TODO
			PopupWindowInstance.document.getElementById(const_pafplayerscmode).value = document.getElementById(const_pafplayerscmode).value;
		}
}


function showconfigs()
{  
	var bshow_window = document.getElementById('configpage').style.visibility == 'hidden';   //th show/to hide window; hide on the second click
//show configuration windows below paf toolbar
  document.getElementById('configpage').style.left="5px";
  document.getElementById('configpage').style.top=(topoffset+30)+"px";
  document.getElementById('configpage').style.visibility = 	(bshow_window ? "visible" : 'hidden');  //close window on second click

	if (bshow_window && OptionUsePopupWindow) {
//if sizes of the frame are too small and configuration windows is (partly) hidden
//show additional popup window with second instance of configuration window
		var frame_height = document.body.clientHeight; 
		var frame_width = document.body.clientWidth; 
		var bframe_is_hidden = (5 + ConfigWindowWidth >= frame_width) || ((topoffset+30) + ConfigWindowHeight >= frame_height);

		if (bframe_is_hidden) { 
		//define a position of the popup window
			var xy = getAnchorWindowPosition('PAFTOOLBAR');
		//define size of pupup windows; minimum size is 100x100 according to standard
			var win_height = (ConfigWindowHeight > 100 ? ConfigWindowHeight : 100);
			var win_width = (ConfigWindowWidth > 100 ? ConfigWindowWidth  : 100);
		
			PopupWindowInstance = window.open(''
				, PopupWindowName
				, 'height='+win_height+'px'
					+ ',width='+win_width+'px'
					+ ',resizable=0,status=0,scrollbars=0,alwaysRaised'
          + ',top='+xy.y+'px'
          + ',left='+xy.x+'px'
			) ;

			if (PopupWindowInstance ==null || typeof(PopupWindowInstance)=="undefined") alert(noPopUpError);
			else {	
				PopupWindowInstance.opener = window;
				PopupWindowInstance.document.open();

				var selected_speed_value = document.getElementById(const_pafplayerspeed).value;			
				var selected_scmode_value = document.getElementById(const_pafplayerscmode).value;

			  var code ="<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0 Transitional//EN\"><html>";
				code = code + "<script language=javascript>";
				code = code + "function change_speed(){ opener.document.getElementById('"+const_pafplayerspeed+"').value = document.getElementById('"+const_pafplayerspeed+"').value; }";
				code = code + "function change_scmode(){ opener.document.getElementById('"+const_pafplayerscmode+"').value = document.getElementById('"+const_pafplayerscmode+"').value; }";
				code = code + "function close_win(){ opener.document.getElementById('configpage').style.visibility='hidden';";
				code = code + "var winPop= opener.open('', \""+PopupWindowName+"\"); if (winPop) winPop.close(); } </script>";
        code = code + "<body style=\"WIDTH:"+win_width+"px;HEIGHT:"+win_height+"px;"
        code = code + "background-image:url('"+pafapiserver+"bg3.gif')\">";
        code = code + "<table style=\"WIDTH:100%;BORDER:0px\" border=0 cellspacing=0 cellpadding=0>";

        code = code + "<tr><td style=\"font-family:verdana,ariel;font-size:10px;font-weight:bold;text-align:center\">"+SpeedHeader+"</td>";
        code = code + "<td><select style=\"font-family:Verdana,Ariel;font-size:10px;margin-bottom:0px\" id=\""+const_pafplayerspeed+"\" onchange=\"javascript:change_speed()\">";
        code = code + "<option "+(selected_speed_value==sp1 ? "selected" : "")+" value=\""+sp1+"\">"+SpeedLevel1+"</option>";
        code = code + "<option "+(selected_speed_value==sp2 ? "selected" : "")+" value=\""+sp2+"\">"+SpeedLevel2+"</option>";
        code = code + "<option "+(selected_speed_value==sp3 ? "selected" : "")+" value=\""+sp3+"\">"+SpeedLevel3+"</option>";
        code = code + "</select></td></tr>";

        code = code + "<tr><td style=\"font-family:verdana,ariel;font-size:10px;font-weight:bold;text-align:center\">"+SCModeHeader+"</td>";
        code = code + "<td><select style=\"font-family:Verdana,Ariel;font-size:10px;margin-bottom:0px\" id=\""+const_pafplayerscmode+"\" onchange=\"javascript:change_scmode()\">";
        code = code + "<option "+(selected_scmode_value==SCMODE1 ? "selected" : "")+" value=\""+SCMODE1+"\">"+TitleSCMode1+"</option>";
        code = code + "<option "+(selected_scmode_value==SCMODE2 ? "selected" : "")+" value=\""+SCMODE2+"\">"+TitleSCMode2+"</option>";
        code = code + "<option "+(selected_scmode_value==SCMODE3 ? "selected" : "")+" value=\""+SCMODE3+"\">"+TitleSCMode3+"</option>";
        code = code + "</select></td></tr>";

        code = code + "<tr><td align=center colspan=2><input type=button value="+CloseDialog+" onclick=\"javascript:close_win()\"></td></tr>";
				code = code + "</table>";
				code = code + "</body></html>";

				PopupWindowInstance.document.write(code);
			}
		}		
 	} else { 
//hide currently visible popup window (if any)
		if (OptionUsePopupWindow) {
			close_configuration_window();
		}
	}
}


function isie()
{
 return ((navigator.userAgent.indexOf("MSIE") != -1) &&  (! isopera())); // && (navigator.userAgent.indexOf("Opera") == -1));
}

function isopera()  
{
 return (navigator.userAgent.indexOf("Opera") != -1);
}

//get text selected in the document or in one of document's frames
function get_selected_text_from_frames(ListFrames) 
{
	try {
   	for (var i=0; i < ListFrames.length; i++) {
   		frame = ListFrames[i];
  		if (frame.name == iframeID) continue;
   		if (frame.window) {
   		//opera, FF
   			if (frame.window.getSelection) {
   				txt = frame.window.getSelection(); 
     			if (txt != '') {
   					return txt; 
   				}
   			}			
   		}

   		if (frame.document) {
   			if (frame.document.getSelection) {
   				txt = frame.document.getSelection(); 
     			if (txt != '') {
   					return txt;
   				}
   			}			
   		//IE
   	  	if (frame.document.selection && (! frame.opera)) { 
   				if (frame.document.selection.createRange != null) {
   					var range = frame.document.selection.createRange(); //crashes in Opera 8.50. bug?
						if (range != null) {
							txt = range.text;
     					if (txt != '') {
   							return txt;
							}
   					}
   				}
     		} 
   		}

  		//search through embedded frames	
	 		if (frame.window ) {
    		if (frame.window.frames) {
  	 			if (frame.window.frames.length > 0) {
    				txt = get_selected_text_from_frames(frame.window.frames);
						if (txt != '') {
    					return txt;
    				}
    			}
    		}  
  		}

   	}
	} catch (e) {
		//!TODO: we have a problem with iframe here (second click of the play button).. frame.name generate exception. why?
	} 	
	return '';
}

function getSel()
{
	var s = getSel2();
	var s2 = encode_to_utf8(s);
	return encode_to_utf8(s);
}

function getSel2() 
{  
	var txt = '';
	if (window.getSelection) {
		txt = window.getSelection();
		if (txt != '') return txt;
	} 

	if (document.getSelection) {
		txt = document.getSelection();
		if (txt != '') return txt;
	} 

	if (document.selection)	{
		txt = document.selection.createRange().text;
		if (txt != '') return txt;
	} 

	if (OptionSearchInFrames) {
	//search selected text in frames
  	var topmost_parent = window.parent; //find topmost parent
  	while (window.parent) {
  		if (topmost_parent.parent == topmost_parent || topmost_parent.parent == null) break;
  		topmost_parent = topmost_parent.parent;
  	}

  	if (topmost_parent.window.frames) { 
  		return get_selected_text_from_frames(topmost_parent.window.frames);
  	} 
	}

	return txt;
}


function GetTheSelectedText(aWindow)
{ 
	try { 
    var selection = getSel(aWindow);
    if (selection != "") return selection;
    var forms = aWindow.frames;
    if (forms) {
    	for (var i=0; ((i < forms.length)); i++) { 
				selection = GetTheSelectedText(forms[i]);
       	if (selection != "")
	   		return selection;
     	}
    }
  } catch (e) {  
    alert("Selectfejl")
  } finally {}
  return ""; // if noting selected is found
}

function getText()
{
  textToRead = getSel(window.top);
}

function pause(numberMillis) 
{
  var now = new Date();
  var exitTime = now.getTime() + numberMillis;
  while (true) {
    now = new Date();
    if (now.getTime() > exitTime)
    { return;
    }
  }
}

function removeiframe()
{
  if (document.getElementById(iframeID))
  {
    if (isopera() || isie())
    {
      var aframe = document.getElementById(iframeID);
      aframe.parentNode.removeChild(aframe); 
    }
  }   
}

function addIframe(textdata)
{ 
  removeiframe();
  if (document.createElement)
  {   
    try {
         var tempIFrame = document.createElement('iframe');
         tempIFrame.setAttribute('id',iframeID);
         tempIFrame.style.border = '0px';
         tempIFrame.style.width = '0px';
         tempIFrame.style.height = '0px';
         
         if (document.body.appendChild)
         {
           iframe = document.body.appendChild(tempIFrame);
         }
        
         if  (document.documentElement.appendChild)
         {
           iframe = document.documentElement.appendChild(tempIFrame);
         }  
          
         if (document.frames) 
         {
           iframe = document.frames[iframeID];
         }
          
        } 
    catch (ex) 
    {
      
      var iframeHTML = '\<iframe id="' + iframeID + '"';
      iframeHTML += ' style="border:0px; width:0px; height:0px;';
      iframeHTML += '"><\/iframe>';
      document.body.innerHTML += iframeHTML;
      iframe = new Object();
      iframe.document = new Object();
      iframe.document.location = new Object();
      iframe.document.location.iframe = 
        document.getElementById(iframeID);
      iframe.document.location.replace = 
      function(location) {
        this.iframe.src = location;
      }
    }
    try
    {
      if (isopera()) {
        pause(200);
        frames[iframeID].document.writeln(textdata);
        frames[iframeID].document.getElementById('startplay').submit();
      }
      else
      {
        if (iframe.contentDocument) { // For NS6
          iframeDocument = iframe.contentDocument; 
        } else if (iframe.contentWindow) { // For IE5.5 and IE6
          iframeDocument = iframe.contentWindow.document;
        } else if (iframe.document) { // For IE5
          iframeDocument = iframe.document;
        }
        iframeDocument.writeln(textdata);
        iframeDocument.getElementById('startplay').submit();
      }  
    }
    catch(e)
    {
      alert("fejl");
    }  
  }
}  


function doplay()
{
  pafplaystatus="0";
  var thetext=getSel();
  
  if (thetext=="")
  {
    alert(notextError);
  }
  else
  {
    try
    {
      showplayerpopup(thetext);
    }
    catch(e){alert(noPopUpError)};  
  }
}
function openWin (fileName, windowName) 
{ 
  return window.open(fileName,windowName,'width=320,height=100,directories=no,location=no,menubar=no,scrollbars=no,status=no,toolbar=no,resizable=no'); 
}

function showplayerpopup(textdata)
{
  var tempdata=textdata;
  if (eventFunction!=''){
    var temp=eventFunction;
    temp = temp.replace("value","tempdata");
    tempdata=eval(temp);
  }
  var pcode=formcode(escape(tempdata));
  addIframe(pcode);
}

function dohelp()
{
  paftoolbarwin.document.location=PAFhelpurl;
}

function closetheplayer()
{
  if (PAFPlayer!=null)
    {PAFPlayer.close();}
}

function Create_PAFToolbar(win,left,top,helpurl,pitch,speed,license)
{
  pafplaystatus="0";
  topoffset=top;
  leftoffset=left;
  paftoolbarwin=win;
  PAFhelpurl=helpurl;
  PAFpitch=pitch;
  PAFspeed=speed;
  PAFlicense=license;
  if (isie()){
    var code=ietoolbarcode();
  } 
  else if (isopera())
  {
    var code=operatoolbarcode();
  } 
  else
  {
    var code = notietoolbarcode();
  } 
  var old = paftoolbarwin.document.body.innerHTML;
  old=old + code;
  paftoolbarwin.document.body.innerHTML = old;
  checktoolbar();
}
function Create_PAFToolbarEX(win,left,top,helpurl,pitch,speed1,speed2,speed3,license)
{
  pafplaystatus="0";
  topoffset=top;
  leftoffset=left;
  paftoolbarwin=win;
  PAFhelpurl=helpurl;
  PAFpitch=pitch;
  //PAFspeed=speed;
  PAFlicense=license;
  sp1=speed1;
  sp2=speed2;
  sp3=speed3;
  extendedplayer=true;
  
  if (isie()){
    var code=ietoolbarcode();
  } 
  else if (isopera())
  {
    var code=operatoolbarcode();
  } 
  else
  {
    var code = notietoolbarcode();
  } 
  var old = paftoolbarwin.document.body.innerHTML;
  old=old + code;
  paftoolbarwin.document.body.innerHTML = old;
  checktoolbar();
}

function Create_PAFToolbarEX2(win,left,top,helpurl,pitch,speed1,speed2,speed3,license,ffunc)
{
  pafplaystatus="0";
  topoffset=top;
  leftoffset=left;
  paftoolbarwin=win;
  PAFhelpurl=helpurl;
  PAFpitch=pitch;
  //PAFspeed=speed;
  PAFlicense=license;
  sp1=speed1;
  sp2=speed2;
  sp3=speed3;
  extendedplayer=true;
  eventFunction=ffunc;
  if (isie()){
    var code=ietoolbarcode();
  } 
  else if (isopera())
  {
    var code=operatoolbarcode();
  } 
  else
  {
    var code = notietoolbarcode();
  } 
  var old = paftoolbarwin.document.body.innerHTML;
  old=old + code;
  paftoolbarwin.document.body.innerHTML = old;
  checktoolbar();
}

function getthetop(){
if (window.pageYOffset) return window.pageYOffset;
else if (document.documentElement && document.documentElement.scrollTop) return document.documentElement.scrollTop;
else if (document.body) return document.body.scrollTop;
}

function checktoolbar()
{
  var theTop = getthetop();
  
  document.getElementById('PAFTOOLBAR').style.top=theTop+topoffset+'px';
  setTimeout("checktoolbar()",200);
}
  

